﻿using AplicacaoInterativa.Models;

namespace AplicacaoInterativa.Repositories.Interfaces
{
    public interface IPedidoRepository
    {
        void CriarPedido(Pedido pedido);
    }
}
