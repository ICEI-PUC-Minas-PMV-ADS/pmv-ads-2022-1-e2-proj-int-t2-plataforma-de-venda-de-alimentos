﻿using AplicacaoInterativa.Repositories;
using AplicacaoInterativa.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace AplicacaoInterativa.Controllers
{
    public class ProdutosController : Controller
    {
        private readonly IProduto _produto;

        public ProdutosController(IProduto produto)
        {
            _produto = produto;
        }

        public IActionResult ListaProdutos()
        {
            var Produtos = _produto.Produtos;
            return View(Produtos);
        }
    }
}
