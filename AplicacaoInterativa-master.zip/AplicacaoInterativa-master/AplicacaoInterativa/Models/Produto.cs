﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AplicacaoInterativa.Models
{   
    [Table("Produto")]
    public class Produto
    {   [Key]
        public int ProdutoId { get; set; }

        [StringLength(100, ErrorMessage = "Tamanho maximo de 100 caracteres.")]
        [Required(ErrorMessage = "Favor informar nome da produto.")]
        public string Nome { get; set; }

        [StringLength(200, ErrorMessage = "Tamanho maximo de 100 caracteres.")]
        [Required(ErrorMessage = "Favor informar a descrição do produto.")]
        public string Descricao { get; set; }
        [Display(Name ="Caminho da imagem.")]
        public string CaminhoImagemUrl { get; set; }

        [StringLength(100, ErrorMessage = "Tamanho maximo de 100 caracteres.")]
        [Required(ErrorMessage = "Favor informar o preço do produto.")]
        [Display(Name ="Preço:")]
        [Column(TypeName ="decimal(10,2)")]
        public decimal Preco { get; set; }
        public bool Estoque { get; set; }

        public int CategoriaId { get; set; }

        public virtual Categoria Categoria { get; set; }
    }
}
