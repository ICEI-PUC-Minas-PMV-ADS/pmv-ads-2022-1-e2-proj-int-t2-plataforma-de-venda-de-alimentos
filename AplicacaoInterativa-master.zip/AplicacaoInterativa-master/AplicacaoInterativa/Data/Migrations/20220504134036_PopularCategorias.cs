﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AplicacaoInterativa.Data.Migrations
{
    public partial class PopularCategorias : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("INSERT INTO Categorias(Nome,Descricao)" +
                "VALUES('Doces','Doces caseiros de primeira qualidade!')");
            migrationBuilder.Sql("INSERT INTO Categorias(Nome,Descricao)" +
               "VALUES('Massas','Diversos tipos de massas.')");
            migrationBuilder.Sql("INSERT INTO Categorias(Nome,Descricao)" +
               "VALUES('Veganos','Produtos sem origem animal.')");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DELETE FROM Categorias");

        }
    }
}
