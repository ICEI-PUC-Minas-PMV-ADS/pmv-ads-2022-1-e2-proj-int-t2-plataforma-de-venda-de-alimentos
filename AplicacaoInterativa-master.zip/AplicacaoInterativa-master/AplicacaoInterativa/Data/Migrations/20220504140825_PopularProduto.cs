﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AplicacaoInterativa.Data.Migrations
{
    public partial class PopularProduto : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("INSERT INTO Produto(CategoriaId,Nome,Descricao,CaminhoImagemUrl,Preco,Estoque)" +
                "VALUES(1,'Brigadeiro','Brigadeiro feito com chocolate belga','~/images/Produtos/brigadeiro.jpg','15.00',1)");
            migrationBuilder.Sql("INSERT INTO Produto(CategoriaId,Nome,Descricao,CaminhoImagemUrl,Preco,Estoque)" +
                "VALUES(2,'Pizza quatro queijos','Parmessão,gorgonzola,mussarela,brie','~/images/Produtos/pizzaportuguesa.jpg','45.00',1)");
            migrationBuilder.Sql("INSERT INTO Produto(CategoriaId,Nome,Descricao,CaminhoImagemUrl,Preco,Estoque)" +
                "VALUES(3,'Taco','Tacos de Grão de bico','~/images/Produtos/tacosgraodebico.jpg','25.00',1)");
        }
        
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DELETE FROM Produto");

        }
    }
}
