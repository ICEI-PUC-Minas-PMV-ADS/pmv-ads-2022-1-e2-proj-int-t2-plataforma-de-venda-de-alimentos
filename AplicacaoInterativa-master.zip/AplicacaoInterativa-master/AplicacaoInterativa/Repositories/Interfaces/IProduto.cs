﻿using AplicacaoInterativa.Models;

namespace AplicacaoInterativa.Repositories.Interfaces
{
    public interface IProduto
    {
        IEnumerable<Produto> Produtos { get; }
        Produto GetProdutoById(int ProdutoId);
    }
}
