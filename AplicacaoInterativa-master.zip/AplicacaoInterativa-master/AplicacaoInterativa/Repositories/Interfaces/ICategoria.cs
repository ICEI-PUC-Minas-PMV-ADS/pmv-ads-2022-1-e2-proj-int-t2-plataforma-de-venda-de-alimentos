﻿using AplicacaoInterativa.Models;

namespace AplicacaoInterativa.Repositories.Interfaces
{
    public interface ICategoria
    {
        IEnumerable<Categoria> Categoria { get; }

    }
}
