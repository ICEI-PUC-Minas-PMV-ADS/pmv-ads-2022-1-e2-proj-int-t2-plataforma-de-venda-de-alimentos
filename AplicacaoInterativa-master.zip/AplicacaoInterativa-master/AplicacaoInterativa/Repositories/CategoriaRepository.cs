﻿using AplicacaoInterativa.Data;
using AplicacaoInterativa.Models;
using AplicacaoInterativa.Repositories.Interfaces;

namespace AplicacaoInterativa.Repositories
{
    public class CategoriaRepository : ICategoria
    {
        private readonly ApplicationDbContext _context;

        public CategoriaRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Categoria> Categoria => _context.Categorias;
    }
}
