﻿using AplicacaoInterativa.Data;
using AplicacaoInterativa.Models;
using AplicacaoInterativa.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace AplicacaoInterativa.Repositories
{
    public class ProdutoRepository : IProduto
    {
        private readonly ApplicationDbContext _context;

        public ProdutoRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Produto> Produtos => _context.Produtos.Include(c=>c.Categoria);

        public Produto GetProdutoById(int ProdutoId)
        {
           return _context.Produtos.FirstOrDefault(p => p.ProdutoId == ProdutoId);
        }
    }
}
